
<?php

return [
    'timezone' => 'America/Mexico_City'
];
